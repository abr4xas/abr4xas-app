	$(document).ready(function () {
		$('#test').rssfeed('http://feeds.feedburner.com/ElBlogDeAbr4xasVol2');
	});
